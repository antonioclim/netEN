#!/usr/bin/env python3
"""
fix_docker_compose.py

Fixes docker-compose.yml files across all WEEK directories.

Resolves:
  1. WARN: the attribute 'version' is obsolete (Docker Compose v2+)
  2. Permission denied on artifacts/ (files created as root inside container)

Usage:
  python3 fix_docker_compose.py                    # Current directory
  python3 fix_docker_compose.py /path/to/repo      # Specific path
  python3 fix_docker_compose.py --dry-run          # Preview changes
"""

import os
import sys
import re
import shutil
from pathlib import Path

# User mapping to add to services
USER_MAPPING = '    user: "${UID:-1000}:${GID:-1000}"'
USER_COMMENT = '    # Run as host user to preserve file ownership'


def fix_docker_compose(file_path: Path, dry_run: bool = False) -> tuple[bool, str]:
    """
    Fix a single docker-compose.yml file.
    Returns (was_modified, description).
    """
    with open(file_path, 'r', encoding='utf-8') as f:
        original = f.read()
    
    content = original
    changes = []
    
    # 1. Remove version line (various formats)
    version_pattern = r'^version:\s*["\']?[\d.]+["\']?\s*\n'
    if re.search(version_pattern, content, re.MULTILINE):
        content = re.sub(version_pattern, '', content, flags=re.MULTILINE)
        changes.append("removed 'version' attribute")
    
    # 2. Add user mapping if not present
    if 'user:' not in content:
        # Find all services and add user: to each
        # Strategy: Add after 'working_dir:', 'network_mode:', or 'volumes:' block
        
        lines = content.split('\n')
        new_lines = []
        i = 0
        added_user = False
        
        while i < len(lines):
            line = lines[i]
            new_lines.append(line)
            
            # Look for good insertion points (end of volumes block or specific keys)
            # We want to add user: at service level (4 spaces indent typically)
            
            # After network_mode: or working_dir:
            if re.match(r'^    (network_mode|working_dir):', line) and not added_user:
                # Check if next line is not already user:
                if i + 1 < len(lines) and not lines[i + 1].strip().startswith('user:'):
                    new_lines.append(USER_COMMENT)
                    new_lines.append(USER_MAPPING)
                    added_user = True
                    changes.append("added user mapping")
            
            # After volumes: block ends (next line with same or less indent)
            elif re.match(r'^    volumes:', line) and not added_user:
                # Skip volume entries (lines starting with 6+ spaces or '      -')
                while i + 1 < len(lines):
                    next_line = lines[i + 1]
                    if next_line.strip() and not next_line.startswith('      '):
                        break
                    i += 1
                    new_lines.append(lines[i])
                
                # Now add user mapping
                if i + 1 < len(lines) and not lines[i + 1].strip().startswith('user:'):
                    new_lines.append(USER_COMMENT)
                    new_lines.append(USER_MAPPING)
                    added_user = True
                    changes.append("added user mapping")
            
            i += 1
        
        if added_user:
            content = '\n'.join(new_lines)
    
    # Check if anything changed
    if content == original:
        return False, "no changes needed"
    
    if dry_run:
        return True, f"would apply: {', '.join(changes)}"
    
    # Create backup
    backup_path = file_path.with_suffix('.yml.bak')
    shutil.copy2(file_path, backup_path)
    
    # Write fixed content
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)
    
    return True, f"applied: {', '.join(changes)}"


def main():
    dry_run = '--dry-run' in sys.argv
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    
    repo_root = Path(args[0]) if args else Path('.')
    
    print("=" * 60)
    print("Docker Compose Fix Script")
    print(f"Repository: {repo_root.absolute()}")
    print(f"Mode: {'DRY RUN' if dry_run else 'APPLY CHANGES'}")
    print("=" * 60)
    print()
    
    fixed = 0
    skipped = 0
    errors = 0
    
    # Find all WEEK directories
    week_dirs = sorted(repo_root.glob('WEEK*'))
    
    for week_dir in week_dirs:
        if not week_dir.is_dir():
            continue
        
        compose_file = week_dir / 'docker' / 'docker-compose.yml'
        
        if not compose_file.exists():
            print(f"[SKIP] {week_dir.name} - no docker-compose.yml")
            skipped += 1
            continue
        
        try:
            modified, desc = fix_docker_compose(compose_file, dry_run)
            if modified:
                print(f"[{'WOULD FIX' if dry_run else 'FIXED'}] {week_dir.name}: {desc}")
                fixed += 1
            else:
                print(f"[OK]   {week_dir.name}: {desc}")
                skipped += 1
        except Exception as e:
            print(f"[ERROR] {week_dir.name}: {e}")
            errors += 1
    
    print()
    print("=" * 60)
    print(f"{'Would fix' if dry_run else 'Fixed'}:  {fixed}")
    print(f"Skipped: {skipped}")
    print(f"Errors:  {errors}")
    print("=" * 60)
    
    if not dry_run and fixed > 0:
        print()
        print("Backups created as *.yml.bak files")
        print()
        print("To commit changes:")
        print("  git add WEEK*/docker/docker-compose.yml")
        print("  git commit -m 'docker-compose: remove obsolete version, add user mapping'")


if __name__ == '__main__':
    main()
